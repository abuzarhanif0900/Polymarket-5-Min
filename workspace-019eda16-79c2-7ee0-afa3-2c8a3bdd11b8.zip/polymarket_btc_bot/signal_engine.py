"""
Signal engine for 5-minute BTC markets.

Logic:
- If BTC spot price has moved up recently, the UP token should also move up.
- If the UP token has not yet moved (or is lagging), buy UP.
- If BTC spot price has moved down recently, buy DOWN if it has not moved.

This is a "spot lead" strategy. It works when Polymarket is slow to react to
BTC spot price moves.
"""

import logging
from typing import Optional

from config import BotConfig

logger = logging.getLogger(__name__)


class Signal:
    """Trading signal."""

    def __init__(
        self,
        side: Optional[str],  # "UP", "DOWN", or None
        confidence: float,  # 0.0 to 1.0
        reason: str,
        spot_change: Optional[float] = None,
        up_mid: Optional[float] = None,
        down_mid: Optional[float] = None,
    ):
        self.side = side
        self.confidence = confidence
        self.reason = reason
        self.spot_change = spot_change
        self.up_mid = up_mid
        self.down_mid = down_mid


class SignalEngine:
    """Generate trading signals from spot price and orderbook data."""

    def __init__(self, config: BotConfig):
        self.config = config

    def generate_signal(
        self,
        spot_change: Optional[float],
        up_orderbook: Optional[dict],
        down_orderbook: Optional[dict],
    ) -> Signal:
        """
        Generate a signal based on spot price move and token orderbook prices.
        """
        # No spot change data.
        if spot_change is None:
            return Signal(None, 0.0, "No spot price data available.")

        # No orderbook data.
        if up_orderbook is None or down_orderbook is None:
            return Signal(None, 0.0, "Missing orderbook data.")

        up_mid = self._get_mid(up_orderbook)
        down_mid = self._get_mid(down_orderbook)

        if up_mid is None or down_mid is None:
            return Signal(None, 0.0, "Cannot calculate mid prices.")

        # Sanity check: UP + DOWN should be close to $1.
        # If not, the market may be illiquid or one side is mispriced.
        total = up_mid + down_mid
        if total < 0.95 or total > 1.05:
            return Signal(
                None,
                0.0,
                f"UP + DOWN = {total:.4f} (illiquid or mispriced market).",
                spot_change=spot_change,
                up_mid=up_mid,
                down_mid=down_mid,
            )

        # Minimum move threshold.
        abs_change = abs(spot_change)
        if abs_change < self.config.SPOT_MOVE_THRESHOLD:
            return Signal(
                None,
                0.0,
                f"Spot move {spot_change:.4%} below threshold.",
                spot_change=spot_change,
                up_mid=up_mid,
                down_mid=down_mid,
            )

        # Strong upward move -> buy UP if it has not fully moved.
        if spot_change > 0:
            # If UP is already expensive (e.g. > 0.75), it has probably moved.
            # If UP is cheap (< 0.55), it is lagging.
            if up_mid < 0.55:
                confidence = min(abs_change / 0.005, 1.0)  # Scale confidence.
                return Signal(
                    "UP",
                    confidence,
                    f"BTC spot up {spot_change:.4%}, UP lagging at {up_mid:.4f}.",
                    spot_change=spot_change,
                    up_mid=up_mid,
                    down_mid=down_mid,
                )
            else:
                return Signal(
                    None,
                    0.0,
                    f"BTC spot up {spot_change:.4%}, but UP already at {up_mid:.4f}.",
                    spot_change=spot_change,
                    up_mid=up_mid,
                    down_mid=down_mid,
                )

        # Strong downward move -> buy DOWN if it has not fully moved.
        else:
            if down_mid < 0.55:
                confidence = min(abs_change / 0.005, 1.0)
                return Signal(
                    "DOWN",
                    confidence,
                    f"BTC spot down {spot_change:.4%}, DOWN lagging at {down_mid:.4f}.",
                    spot_change=spot_change,
                    up_mid=up_mid,
                    down_mid=down_mid,
                )
            else:
                return Signal(
                    None,
                    0.0,
                    f"BTC spot down {spot_change:.4%}, but DOWN already at {down_mid:.4f}.",
                    spot_change=spot_change,
                    up_mid=up_mid,
                    down_mid=down_mid,
                )

    @staticmethod
    def _get_mid(orderbook: dict) -> Optional[float]:
        """Calculate mid price from best bid and ask."""
        bids = orderbook.get("bids", [])
        asks = orderbook.get("asks", [])
        if not bids or not asks:
            return None
        best_bid = float(bids[0]["price"])
        best_ask = float(asks[0]["price"])
        return (best_bid + best_ask) / 2.0
