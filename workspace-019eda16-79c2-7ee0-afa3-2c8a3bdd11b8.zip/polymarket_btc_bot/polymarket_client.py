"""
Polymarket client for reading market data.

Uses the official py-clob-client for orderbook data and the Gamma API
for market discovery. This is the most reliable way to access Polymarket.

In paper trading mode, we do not need API credentials.
For live trading, you will provide credentials via .env.
"""

import json
import logging
import time
from datetime import datetime, timezone
from typing import Any, Dict, Optional

import aiohttp
from py_clob_client.client import ClobClient
from py_clob_client.constants import POLYGON

logger = logging.getLogger(__name__)


class PolymarketClient:
    """Polymarket client using the official SDK."""

    def __init__(self, config):
        self.config = config
        self.clob_host = config.POLY_CLOB_HOST
        self.gamma_api = config.POLY_GAMMA_API

        # Official SDK client for read-only operations.
        # No API key needed for public endpoints.
        self._clob = ClobClient(self.clob_host, chain_id=POLYGON)

        # Cache for active market.
        self._active_market: Optional[Dict[str, Any]] = None
        self._market_cache_time: float = 0
        self._market_cache_ttl: float = 30.0  # Short TTL for 5m rotation.

    async def _get(self, url: str) -> Any:
        """Make a GET request to Gamma API and return JSON."""
        async with aiohttp.ClientSession() as session:
            async with session.get(url, timeout=10.0) as resp:
                resp.raise_for_status()
                return await resp.json()

    @staticmethod
    def _get_5min_round_timestamp(utc_now: Optional[datetime] = None) -> int:
        """Return the Unix timestamp of the current 5-minute round start (UTC)."""
        if utc_now is None:
            utc_now = datetime.now(timezone.utc)
        seconds = int(utc_now.timestamp())
        return seconds - (seconds % 300)

    async def get_event_by_slug(self, slug: str) -> Optional[Dict[str, Any]]:
        """Fetch a Polymarket event by its slug."""
        try:
            url = f"{self.gamma_api}/events?slug={slug}"
            events = await self._get(url)
            if isinstance(events, list) and len(events) > 0:
                event = events[0]
                # Use the first market in the event.
                markets = event.get("markets", [])
                if markets:
                    market = self._extract_tokens(markets[0])
                    if market:
                        market["event_slug"] = slug
                        market["event_title"] = event.get("title")
                        market["round_start_ts"] = None
                        return market
                logger.warning("Event has no markets: %s", slug)
            return None
        except Exception as e:
            logger.error("Failed to fetch event by slug %s: %s", slug, e)
            return None

    async def find_current_5min_btc_market(self) -> Optional[Dict[str, Any]]:
        """
        Find the current 5-minute BTC market by computing the round timestamp.
        Tries current round, then previous round, then next round.
        """
        now = datetime.now(timezone.utc)
        current_ts = self._get_5min_round_timestamp(now)

        # Try current, previous, and next rounds.
        candidates = [current_ts, current_ts - 300, current_ts + 300]

        for ts in candidates:
            slug = self.config.FIVE_MIN_SLUG_TEMPLATE.format(timestamp=ts)
            market = await self.get_event_by_slug(slug)
            if market:
                # Check if market is still active.
                end_date = market.get("end_date")
                if end_date:
                    try:
                        expiry = datetime.fromisoformat(end_date.replace("Z", "+00:00"))
                        if expiry < now:
                            logger.debug("Round %s already expired, trying next.", slug)
                            continue
                    except Exception:
                        pass

                market["round_start_ts"] = ts
                market["round_end_ts"] = ts + 300
                logger.info(
                    "Found 5m market: %s | Round: %s UTC - %s UTC",
                    market.get("question"),
                    datetime.fromtimestamp(ts, timezone.utc).strftime("%H:%M"),
                    datetime.fromtimestamp(ts + 300, timezone.utc).strftime("%H:%M"),
                )
                return market

        logger.warning(
            "Could not find current 5-minute BTC market. Tried slugs: %s",
            [self.config.FIVE_MIN_SLUG_TEMPLATE.format(timestamp=t) for t in candidates],
        )
        return None

    async def get_market_by_condition_id(self, condition_id: str) -> Optional[Dict[str, Any]]:
        """Fetch a specific market by its condition ID."""
        try:
            url = f"{self.gamma_api}/markets/{condition_id}"
            market = await self._get(url)
            if not isinstance(market, dict):
                return None
            return self._extract_tokens(market)
        except Exception as e:
            logger.error("Failed to fetch market by condition ID: %s", e)
            return None

    def _extract_tokens(self, market: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Extract up/down token IDs and other useful fields from a market."""
        # Gamma API stores token IDs in 'clobTokenIds' as a JSON string.
        clob_token_ids_raw = market.get("clobTokenIds")
        outcomes_raw = market.get("outcomes")

        token_ids = []
        outcomes = []

        try:
            if isinstance(clob_token_ids_raw, str) and clob_token_ids_raw:
                token_ids = json.loads(clob_token_ids_raw)
            elif isinstance(clob_token_ids_raw, list):
                token_ids = clob_token_ids_raw
        except Exception as e:
            logger.warning("Failed to parse clobTokenIds: %s", e)

        try:
            if isinstance(outcomes_raw, str) and outcomes_raw:
                outcomes = json.loads(outcomes_raw)
            elif isinstance(outcomes_raw, list):
                outcomes = outcomes_raw
        except Exception as e:
            logger.warning("Failed to parse outcomes: %s", e)

        if len(token_ids) < 2:
            logger.warning(
                "Could not find enough token IDs for market: %s", market.get("question")
            )
            return None

        # Map outcomes to token IDs.
        up_token = None
        down_token = None

        for i, outcome in enumerate(outcomes):
            if i >= len(token_ids):
                break
            outcome_lower = outcome.lower()
            token_id = token_ids[i]
            if outcome_lower in ["up", "yes"]:
                up_token = token_id
            elif outcome_lower in ["down", "no"]:
                down_token = token_id

        # If we couldn't map by name, assume first token is UP/YES and second is DOWN/NO.
        if not up_token and token_ids:
            up_token = token_ids[0]
        if not down_token and len(token_ids) > 1:
            down_token = token_ids[1]

        if not up_token or not down_token:
            logger.warning(
                "Could not find UP/DOWN tokens for market: %s", market.get("question")
            )
            return None

        return {
            "condition_id": market.get("conditionId"),
            "question": market.get("question"),
            "slug": market.get("slug"),
            "end_date": market.get("endDate"),
            "up_token_id": up_token,
            "down_token_id": down_token,
        }

    async def find_active_btc_market(self) -> Optional[Dict[str, Any]]:
        """
        Find an active BTC market matching the configured settings.
        """
        now = time.time()
        if (
            self._active_market
            and (now - self._market_cache_time) < self._market_cache_ttl
        ):
            return self._active_market

        # Option 1: Auto-rotate 5-minute markets.
        if self.config.AUTO_ROTATE_5MIN:
            market = await self.find_current_5min_btc_market()
            if market:
                self._active_market = market
                self._market_cache_time = now
                return market

        # Option 2: Use configured event slug.
        if self.config.TARGET_EVENT_SLUG:
            market = await self.get_event_by_slug(self.config.TARGET_EVENT_SLUG)
            if market:
                self._active_market = market
                self._market_cache_time = now
                return market
            else:
                logger.error(
                    "Could not load configured event slug: %s",
                    self.config.TARGET_EVENT_SLUG,
                )
                return None

        # Option 3: Use configured condition ID.
        if self.config.TARGET_MARKET_CONDITION_ID:
            market = await self.get_market_by_condition_id(
                self.config.TARGET_MARKET_CONDITION_ID
            )
            if market:
                self._active_market = market
                self._market_cache_time = now
                logger.info("Using configured market: %s", market["question"])
                return market
            else:
                logger.error(
                    "Could not load configured market: %s",
                    self.config.TARGET_MARKET_CONDITION_ID,
                )
                return None

        # Option 4: Search for a matching market.
        markets = await self._fetch_markets()
        duration = self.config.MARKET_DURATION.lower()

        for market in markets:
            if not isinstance(market, dict):
                continue

            question = (market.get("question") or "").lower()
            slug = (market.get("slug") or "").lower()

            # Check BTC keywords.
            has_btc = any(kw.lower() in question or kw.lower() in slug for kw in self.config.MARKET_KEYWORDS)
            if not has_btc:
                continue

            # Check duration keywords.
            duration_match = False
            if duration == "5min":
                duration_match = "5-minute" in question or "5 minute" in question or "5m" in slug
            elif duration == "15min":
                duration_match = "15-minute" in question or "15 minute" in question or "15m" in slug
            elif duration == "1h":
                duration_match = "1-hour" in question or "1 hour" in question or "1h" in slug
            elif duration == "4h":
                duration_match = "4-hour" in question or "4 hour" in question or "4h" in slug
            elif duration == "daily":
                duration_match = "daily" in question or "1-day" in question or "24-hour" in question
            elif duration == "any":
                duration_match = True
            else:
                duration_match = True

            if not duration_match:
                continue

            extracted = self._extract_tokens(market)
            if extracted:
                self._active_market = extracted
                self._market_cache_time = now
                logger.info("Found active market: %s", extracted["question"])
                return extracted

        logger.warning(
            "No active %s BTC market found. Try setting TARGET_EVENT_SLUG, TARGET_MARKET_CONDITION_ID, or AUTO_ROTATE_5MIN.",
            self.config.MARKET_DURATION,
        )
        return None

    async def _fetch_markets(self) -> list:
        """Fetch active markets from Gamma API."""
        try:
            # Note: Gamma API may limit results to 100 regardless of the limit param.
            url = (
                f"{self.gamma_api}/markets?"
                f"active=true&"
                f"closed=false&"
                f"archived=false&"
                f"limit=100"
            )
            data = await self._get(url)
            if isinstance(data, list):
                return data
            elif isinstance(data, dict):
                return data.get("markets", [])
            return []
        except Exception as e:
            logger.error("Failed to fetch markets: %s", e)
            return []

    def get_orderbook(self, token_id: str) -> Optional[Dict[str, Any]]:
        """
        Get the orderbook for a token ID using the official py-clob-client.
        Returns dict with 'bids' and 'asks' lists.
        """
        try:
            book = self._clob.get_order_book(token_id)
            # Convert SDK OrderBookSummary to a plain dict.
            return {
                "bids": [
                    {"price": float(b.price), "size": float(b.size)}
                    for b in book.bids
                ],
                "asks": [
                    {"price": float(a.price), "size": float(a.size)}
                    for a in book.asks
                ],
                "last_trade_price": book.last_trade_price,
                "tick_size": book.tick_size,
            }
        except Exception as e:
            logger.error("Failed to get orderbook for %s: %s", token_id[:12], e)
            return None

    @staticmethod
    def get_mid_price(orderbook: Dict[str, Any]) -> Optional[float]:
        """Calculate mid price from best bid and best ask."""
        bids = orderbook.get("bids", [])
        asks = orderbook.get("asks", [])

        if not bids or not asks:
            return None

        best_bid = float(bids[0]["price"])
        best_ask = float(asks[0]["price"])
        return (best_bid + best_ask) / 2.0

    @staticmethod
    def get_spread(orderbook: Dict[str, Any]) -> Optional[float]:
        """Return bid-ask spread."""
        bids = orderbook.get("bids", [])
        asks = orderbook.get("asks", [])

        if not bids or not asks:
            return None

        best_bid = float(bids[0]["price"])
        best_ask = float(asks[0]["price"])
        return best_ask - best_bid
