# Polymarket BTC Trading Bot

A beginner-friendly Python bot for trading Polymarket's BTC up/down markets. **It starts in paper trading mode by default** so you can test safely.

> **Important:** This bot was designed for short-duration BTC up/down markets (5-minute, 15-minute, 1-hour). To use it, you must provide the **event slug** or **condition ID** of the market you want to trade.

## What It Does

- Connects to a **BTC spot price feed** (Coinbase, Binance, or Kraken).
- Finds a specific BTC market on Polymarket using its event slug or condition ID.
- Monitors the **UP** and **DOWN** token orderbooks.
- Generates a **signal** when BTC spot moves but the Polymarket token is lagging.
- Simulates trades in **paper trading mode** and tracks P&L in a CSV file.
- Has risk management: daily loss limit, trade cooldown, max trade size.

## ⚠️ Important

This bot is for **learning and testing**. It is **not guaranteed to make money**. Short-duration crypto markets are extremely competitive, and fees/slippage can erase small edges.

## Setup

### 1. Install Python

You need Python 3.10 or higher.

### 2. Install Dependencies

```bash
cd polymarket_btc_bot
pip install -r requirements.txt
```

### 3. Find Your Market on Polymarket

The bot needs the exact event slug or condition ID of the market you want to trade.

1. Go to https://polymarket.com and find the BTC market (e.g., **BTC Up or Down 5m**).
2. Click on it and look at the URL in your browser.
3. The URL will look like:
   ```
   https://polymarket.com/event/bitcoin-up-or-down-5m-on-june-18-2026
   ```
4. Copy the slug (the part after `/event/`):
   ```
   bitcoin-up-or-down-5m-on-june-18-2026
   ```
5. Open `config.py` and set:
   ```python
   TARGET_EVENT_SLUG = "bitcoin-up-or-down-5m-on-june-18-2026"
   ```

> **Note:** I could not find the exact 5m event slug through the Polymarket API automatically. The screenshot you shared shows the market exists, but I need you to provide the URL or slug from the UI so the bot can connect to it.

### Alternative: Use the Daily BTC Up/Down Market (For Testing)

If you can't find the 5m slug right now, you can test the bot with the daily market:

```python
TARGET_EVENT_SLUG = "bitcoin-up-or-down-on-june-18-2026"
```

This is a real Polymarket BTC up/down market, but it resolves once per day based on Binance 1-minute candles. The spot-lead strategy may not be ideal for it, but it will let you verify the bot works.

### 4. Run in Paper Trading Mode

```bash
python main.py
```

This will:
- Start the spot price feed.
- Load the market from the event slug.
- Log signals and simulate trades.
- Save simulated trades to `trades.csv`.
- Log everything to `bot.log` and the console.

### 5. Stop the Bot

Press `Ctrl+C`.

## Configuration

Open `config.py` and adjust:

| Setting | What It Does | Default |
|---------|--------------|---------|
| `DRY_RUN` | True = paper trading, False = live trading | `True` |
| `CAPITAL_USD` | Total capital you are risking | `$100` |
| `MAX_TRADE_SIZE_USD` | Max dollars per trade | `$5` |
| `DAILY_MAX_LOSS_PCT` | Stop trading after losing this % of capital | `20%` |
| `SPOT_MOVE_THRESHOLD` | Minimum BTC spot move to trigger a signal | `0.1%` |
| `SPOT_LOOKBACK_SECONDS` | How far back to measure BTC spot move | `15s` |
| `TARGET_EVENT_SLUG` | Event slug from Polymarket URL | `None` |
| `TARGET_MARKET_CONDITION_ID` | Condition ID (alternative to slug) | `None` |
| `SPOT_FEED_SOURCE` | Price feed: "coinbase", "binance", "kraken" | `coinbase` |

## How the Signal Works

The bot uses a **spot lead** strategy:

1. If BTC spot price went up in the last 15 seconds, the UP token should also go up.
2. If the UP token has **not** moved yet (mid price < 0.55), the bot simulates buying UP.
3. If BTC spot price went down, the bot looks to buy DOWN if it is lagging.

This only works if Polymarket is slow to react to spot moves. On fast markets, the signal will be too late.

## Live Trading

To switch to live trading:

1. Copy `.env.example` to `.env`:
   ```bash
   cp .env.example .env
   ```
2. Fill in your Polymarket API credentials and private key.
3. Change `DRY_RUN` to `false` in `config.py`.
4. **Only use a small amount of capital that you can afford to lose.**

## Files

- `main.py` — Entry point.
- `config.py` — All settings.
- `spot_feed.py` — Multi-source BTC spot price feed.
- `polymarket_client.py` — Polymarket market data (events + orderbooks).
- `signal_engine.py` — Signal generation logic.
- `paper_trader.py` — Paper trading simulator and P&L tracker.
- `find_markets.py` — Helper to find active BTC up/down events.
- `trades.csv` — Simulated trade history.
- `bot.log` — Detailed logs.

## Next Steps

1. **Find the exact 5m BTC market slug on Polymarket and set it in `config.py`.**
2. **Run `python main.py` in paper mode for at least a few hours.**
3. Check the win rate and P&L in the logs and `trades.csv`.
4. If results look good, consider live trading with **$5–10** first.
5. If results are bad, tweak the signal settings or try a different strategy.

## Risks

- **No guaranteed profit.** This is a competitive market.
- **Slippage and fees** can turn a winning signal into a losing trade.
- **Latency** matters. Running locally may be slower than a cloud server.
- **Past performance** does not predict future results.
- **Market availability** varies. You must find the active market slug each time.

## Need Help?

If you can share the exact URL of the **BTC Up or Down 5m** market from your screenshot, I can plug it into the bot for you.
