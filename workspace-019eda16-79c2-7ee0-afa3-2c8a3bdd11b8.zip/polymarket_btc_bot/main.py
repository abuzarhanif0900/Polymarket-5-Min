"""
Main entry point for the Polymarket BTC trading bot.

This bot:
1. Connects to a BTC spot price feed (Coinbase, Binance, or Kraken).
2. Finds an active BTC market on Polymarket (auto-rotating 5m markets, or a fixed market).
3. Monitors the orderbook for UP and DOWN tokens.
4. Generates a signal when BTC spot moves but the Polymarket token is lagging.
5. Simulates trades in paper trading mode (or real trades in live mode).
6. Closes positions before expiry and switches to the next round.

Run with:
    python main.py

Stop with Ctrl+C.
"""

import asyncio
import logging
import signal
import sys
import time
from datetime import datetime, timezone
from typing import Optional

from config import BotConfig
from paper_trader import PaperTrader
from polymarket_client import PolymarketClient
from signal_engine import SignalEngine
from spot_feed import SpotPriceFeed

# -------------------------------
# Setup Logging
# -------------------------------
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
    handlers=[
        logging.FileHandler("bot.log"),
        logging.StreamHandler(sys.stdout),
    ],
)
# Suppress noisy third-party logs.
logging.getLogger("httpx").setLevel(logging.WARNING)
logging.getLogger("httpcore").setLevel(logging.WARNING)
logger = logging.getLogger(__name__)


class TradingBot:
    """Main trading bot."""

    def __init__(self, config: BotConfig):
        self.config = config
        self.spot = SpotPriceFeed(config)
        self.polymarket = PolymarketClient(config)
        self.signal_engine = SignalEngine(config)
        self.trader = PaperTrader(config)

        self._running = False
        self._shutdown_event = asyncio.Event()
        self._active_market: Optional[dict] = None

    async def run(self):
        """Main loop."""
        self._running = True

        # Start spot price feed.
        await self.spot.start()

        # Wait for a price. WebSocket may fail, so REST fallback is used.
        logger.info("Waiting for BTC spot price feed...")
        price = await self._wait_for_price(timeout=20.0)

        if not price:
            logger.error("Could not get BTC spot price after 20 seconds. Exiting.")
            await self.spot.stop()
            return

        logger.info("Got BTC price: $%.2f", price)
        logger.info("Bot started. DRY_RUN=%s", self.config.DRY_RUN)
        logger.info(
            "Capital: $%.2f | Max trade: $%.2f | Auto-rotate 5m: %s",
            self.config.CAPITAL_USD,
            self.config.MAX_TRADE_SIZE_USD,
            self.config.AUTO_ROTATE_5MIN,
        )

        # Load initial market.
        await self._refresh_market()
        if not self._active_market:
            logger.error("No active BTC market found. Exiting.")
            logger.info("Tip: Set TARGET_EVENT_SLUG in config.py or enable AUTO_ROTATE_5MIN.")
            await self.spot.stop()
            return

        # Main loop.
        try:
            while self._running:
                if self._shutdown_event.is_set():
                    break

                # Check if we need to rotate to a new 5-minute market.
                await self._maybe_rotate_market()

                if not self._active_market:
                    logger.warning("No active market. Waiting...")
                    await asyncio.sleep(2.0)
                    continue

                await self._tick(self._active_market)

                # Sleep before next check.
                await asyncio.sleep(2.0)

        except asyncio.CancelledError:
            logger.info("Main loop cancelled.")
        finally:
            logger.info("Shutting down...")
            await self.spot.stop()
            self._print_final_stats()

    async def _wait_for_price(self, timeout: float) -> Optional[float]:
        """Wait until we get a price from the spot feed."""
        deadline = time.time() + timeout
        while time.time() < deadline:
            if self.spot.has_price():
                return self.spot.get_latest()
            await asyncio.sleep(0.5)
        return None

    async def _refresh_market(self):
        """Load the current active market."""
        market = await self.polymarket.find_active_btc_market()
        if market and market != self._active_market:
            if self._active_market:
                logger.info(
                    "Switching market from '%s' to '%s'",
                    self._active_market.get("question"),
                    market.get("question"),
                )
            self._active_market = market

    async def _maybe_rotate_market(self):
        """For 5m auto-rotate, check if current round is expiring and switch."""
        if not self.config.AUTO_ROTATE_5MIN:
            return

        now = datetime.now(timezone.utc)
        round_end = self._active_market.get("round_end_ts")

        # If we don't have round end info, refresh every 30 seconds.
        if not round_end:
            await self._refresh_market()
            return

        seconds_to_expiry = round_end - now.timestamp()

        # If market is expiring soon, close positions and refresh market.
        if seconds_to_expiry < self.config.FIVE_MIN_EXIT_BUFFER_SECONDS:
            if self.trader.positions:
                logger.info(
                    "5m round expires in %.1fs. Closing positions before rotation.",
                    seconds_to_expiry,
                )
                final_up_price = self._estimate_up_resolution(self._active_market)
                self.trader.close_all_positions(final_up_price)

            # Refresh to the next round.
            await self._refresh_market()
            return

        # Also refresh periodically to catch newly created rounds.
        # Refresh if we are in the first 10 seconds of a new round.
        current_round_start = PolymarketClient._get_5min_round_timestamp(now)
        active_round_start = self._active_market.get("round_start_ts")
        if active_round_start and current_round_start != active_round_start:
            logger.info(
                "Detected new 5m round (current: %s, active: %s). Rotating.",
                current_round_start,
                active_round_start,
            )
            await self._refresh_market()

    async def _tick(self, active_market: dict):
        """One iteration of the trading loop."""
        # 1. Get spot price change.
        spot_change = self.spot.get_price_change(self.config.SPOT_LOOKBACK_SECONDS)
        latest_spot = self.spot.get_latest()

        # 2. Get orderbooks (sync call via py-clob-client).
        up_book = self.polymarket.get_orderbook(active_market["up_token_id"])
        down_book = self.polymarket.get_orderbook(active_market["down_token_id"])

        # 3. Generate signal.
        signal = self.signal_engine.generate_signal(spot_change, up_book, down_book)

        # 4. Log status.
        round_info = ""
        if active_market.get("round_start_ts"):
            start = datetime.fromtimestamp(active_market["round_start_ts"], timezone.utc).strftime("%H:%M")
            end = datetime.fromtimestamp(active_market.get("round_end_ts", active_market["round_start_ts"] + 300), timezone.utc).strftime("%H:%M")
            round_info = f" | Round: {start}-{end} UTC"

        logger.info(
            "Spot: $%.2f (change: %.4f) | UP: %.4f | DOWN: %.4f | Signal: %s | Reason: %s%s",
            latest_spot or 0.0,
            spot_change or 0.0,
            signal.up_mid or 0.0,
            signal.down_mid or 0.0,
            signal.side or "NONE",
            signal.reason,
            round_info,
        )

        # 5. Execute if signal exists and no open positions.
        if signal.side and not self.trader.positions:
            if self.trader.can_trade():
                entry_price = signal.up_mid if signal.side == "UP" else signal.down_mid
                self.trader.open_position(
                    side=signal.side,
                    entry_price=entry_price,
                    size_usd=self.config.MAX_TRADE_SIZE_USD,
                    market_question=active_market["question"],
                )
            else:
                logger.info("Signal generated but trading not allowed (risk/cooldown).")

        # 6. Print stats periodically.
        if int(time.time()) % 60 == 0:
            self._print_stats()

    def _estimate_up_resolution(self, active_market: dict) -> float:
        """
        Estimate the final UP token resolution price.
        For paper trading, we use the current orderbook mid as a proxy.
        In live trading, the Chainlink oracle determines the final price.
        """
        up_book = self.polymarket.get_orderbook(active_market["up_token_id"])
        if up_book:
            bids = up_book.get("bids", [])
            asks = up_book.get("asks", [])
            if bids and asks:
                return (float(bids[0]["price"]) + float(asks[0]["price"])) / 2.0
        return 0.5

    def _print_stats(self):
        """Print current trading stats."""
        stats = self.trader.get_stats()
        logger.info(
            "STATS | PnL: $%.2f | Wins: %d | Losses: %d | Win Rate: %.1f%% | Open: %d",
            stats["daily_pnl"],
            stats["daily_wins"],
            stats["daily_losses"],
            stats["win_rate"],
            stats["open_positions"],
        )

    def _print_final_stats(self):
        """Print final stats on shutdown."""
        stats = self.trader.get_stats()
        logger.info("=" * 60)
        logger.info("FINAL STATS")
        logger.info("=" * 60)
        logger.info("Daily PnL:        $%.2f", stats["daily_pnl"])
        logger.info("Wins:             %d", stats["daily_wins"])
        logger.info("Losses:           %d", stats["daily_losses"])
        logger.info("Win Rate:         %.1f%%", stats["win_rate"])
        logger.info("Total Trades:     %d", stats["daily_wins"] + stats["daily_losses"])
        logger.info("=" * 60)

    def shutdown(self):
        """Signal the bot to shut down."""
        logger.info("Shutdown signal received.")
        self._running = False
        self._shutdown_event.set()


async def main():
    config = BotConfig()
    bot = TradingBot(config)

    # Handle Ctrl+C.
    loop = asyncio.get_event_loop()
    for sig in (signal.SIGINT, signal.SIGTERM):
        loop.add_signal_handler(sig, bot.shutdown)

    await bot.run()


if __name__ == "__main__":
    asyncio.run(main())
