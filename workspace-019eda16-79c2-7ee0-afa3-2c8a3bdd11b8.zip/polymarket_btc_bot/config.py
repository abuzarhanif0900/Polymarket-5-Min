"""
Configuration for the Polymarket BTC trading bot.

All tunable settings are here. For live trading, you will set your
Polymarket API credentials in the .env file.
"""

from dataclasses import dataclass
from typing import Optional


@dataclass
class BotConfig:
    """Bot configuration."""

    # -------------------------------
    # Trading Mode
    # -------------------------------
    # True = paper trading (no real orders). False = live trading.
    DRY_RUN: bool = True

    # -------------------------------
    # Capital & Risk
    # -------------------------------
    # Total capital you are willing to risk.
    CAPITAL_USD: float = 100.0

    # Maximum USD per trade.
    MAX_TRADE_SIZE_USD: float = 5.0

    # Stop trading if daily loss reaches this percentage of capital.
    DAILY_MAX_LOSS_PCT: float = 0.20  # 20% of $100 = $20

    # Stop trading if daily profit reaches this percentage (optional safety).
    DAILY_MAX_PROFIT_PCT: float = 0.50  # 50% of $100 = $50

    # Max number of trades per market round.
    MAX_TRADES_PER_ROUND: int = 1

    # Cooldown between trades in seconds.
    TRADE_COOLDOWN_SECONDS: float = 30.0

    # -------------------------------
    # Signal Settings
    # -------------------------------
    # How many seconds of spot price history to keep.
    SPOT_HISTORY_SECONDS: int = 120

    # Minimum spot price move (in decimal, e.g. 0.001 = 0.1%) to trigger a signal.
    SPOT_MOVE_THRESHOLD: float = 0.001

    # Lookback window in seconds for measuring the spot move.
    SPOT_LOOKBACK_SECONDS: float = 15.0

    # Maximum age of the Polymarket orderbook in seconds before we ignore it.
    ORDERBOOK_MAX_AGE_SECONDS: float = 5.0

    # -------------------------------
    # Polymarket Market Selection
    # -------------------------------
    # IMPORTANT: Find your market on https://polymarket.com and copy the event slug
    # from the URL (the part after /event/). For example:
    #   https://polymarket.com/event/btc-updown-5m-1781775300
    #   -> slug = "btc-updown-5m-1781775300"
    # If you set this, the bot will trade THIS specific market only.
    TARGET_EVENT_SLUG: Optional[str] = None

    # Option 2: Manually specify the market condition ID.
    TARGET_MARKET_CONDITION_ID: Optional[str] = None

    # Option 3: Auto-rotate through 5-minute BTC markets.
    # When True, the bot automatically finds the current 5-minute BTC market
    # and switches to the next round when the current one expires.
    AUTO_ROTATE_5MIN: bool = True

    # Template for 5-minute BTC market slugs.
    # The {timestamp} is the Unix timestamp of the 5-minute round start (UTC).
    FIVE_MIN_SLUG_TEMPLATE: str = "btc-updown-5m-{timestamp}"

    # How many seconds before a 5-minute round ends to stop trading and close positions.
    FIVE_MIN_EXIT_BUFFER_SECONDS: float = 10.0

    # Option 4: Search for an active market (fallback, less reliable).
    # Market duration: "5min", "15min", "1h", "4h", "daily", or "any".
    MARKET_DURATION: str = "any"

    # Keywords to search for in the market title.
    MARKET_KEYWORDS: tuple = ("bitcoin", "btc")

    # Polymarket CLOB host.
    POLY_CLOB_HOST: str = "https://clob.polymarket.com"

    # Chain ID for Polygon mainnet.
    POLY_CHAIN_ID: int = 137

    # Gamma API for market discovery.
    POLY_GAMMA_API: str = "https://gamma-api.polymarket.com"

    # -------------------------------
    # Spot Price Feed
    # -------------------------------
    # The bot tries multiple feeds in order. Pick your preferred one.
    # Options: "binance", "coinbase", "kraken"
    SPOT_FEED_SOURCE: str = "coinbase"

    # Coinbase (default, reliable public API)
    COINBASE_SYMBOL: str = "BTC-USD"
    COINBASE_WS_URL: str = "wss://ws-feed.exchange.coinbase.com"
    COINBASE_REST_URL: str = "https://api.exchange.coinbase.com/products/BTC-USD/ticker"

    # Binance (fallback)
    BINANCE_SYMBOL: str = "BTCUSDT"
    BINANCE_WS_URL: str = "wss://stream.binance.com:9443/ws/btcusdt@trade"
    BINANCE_REST_URL: str = "https://api.binance.com/api/v3/ticker/price?symbol=BTCUSDT"

    # Kraken (fallback)
    KRAKEN_SYMBOL: str = "XBTUSD"
    KRAKEN_REST_URL: str = "https://api.kraken.com/0/public/Ticker?pair=XBTUSD"

    # -------------------------------
    # Execution
    # -------------------------------
    # Use maker orders only (post_only=True) to avoid taker fees.
    # Polymarket has 0% maker fee and ~0.2-0.4% taker fee.
    USE_MAKER_ONLY: bool = True

    # Price offset for maker orders (in cents on the $0-1 price scale).
    # E.g. 0.002 means place order 0.2% better than mid price.
    MAKER_PRICE_OFFSET: float = 0.002

    # -------------------------------
    # Logging
    # -------------------------------
    # CSV file to track simulated trades.
    TRADES_CSV: str = "trades.csv"

    # Log level: DEBUG, INFO, WARNING, ERROR.
    LOG_LEVEL: str = "INFO"

    # -------------------------------
    # Polymarket API Credentials (for live trading only)
    # -------------------------------
    # These are loaded from environment variables or .env file.
    POLY_PRIVATE_KEY: Optional[str] = None
    POLY_FUNDER_ADDRESS: Optional[str] = None
    POLY_API_KEY: Optional[str] = None
    POLY_API_SECRET: Optional[str] = None
    POLY_API_PASSPHRASE: Optional[str] = None
