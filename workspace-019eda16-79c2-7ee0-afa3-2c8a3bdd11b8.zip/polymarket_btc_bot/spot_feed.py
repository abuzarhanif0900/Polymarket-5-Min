"""
BTC spot price feed with multiple source support.

Tries sources in order:
1. WebSocket (Coinbase or Binance)
2. REST API fallback for the primary source
3. Other REST API fallbacks

This makes the bot robust against regional blocks or exchange outages.
"""

import asyncio
import json
import logging
import time
from collections import deque
from typing import Deque, List, Optional

import aiohttp
import websockets

logger = logging.getLogger(__name__)


class SpotPriceFeed:
    """Multi-source BTC spot price feed."""

    def __init__(self, config):
        self.config = config
        self.history_seconds = config.SPOT_HISTORY_SECONDS

        # Price history: list of (timestamp_ms, price).
        self.prices: Deque[tuple] = deque()

        # Latest price.
        self.latest_price: Optional[float] = None
        self.latest_time: Optional[float] = None

        # Control flags.
        self._running = False
        self._tasks: List[asyncio.Task] = []

    async def start(self):
        """Start the price feed."""
        self._running = True

        # Start WebSocket task for the preferred source.
        if self.config.SPOT_FEED_SOURCE == "binance":
            self._tasks.append(asyncio.create_task(self._run_binance_ws()))
        elif self.config.SPOT_FEED_SOURCE == "coinbase":
            self._tasks.append(asyncio.create_task(self._run_coinbase_ws()))
        else:
            logger.warning("Unknown SPOT_FEED_SOURCE: %s", self.config.SPOT_FEED_SOURCE)

        logger.info("Spot price feed started (source: %s)", self.config.SPOT_FEED_SOURCE)

    async def stop(self):
        """Stop the price feed."""
        self._running = False
        for task in self._tasks:
            task.cancel()
            try:
                await task
            except asyncio.CancelledError:
                pass
        self._tasks.clear()
        logger.info("Spot price feed stopped.")

    # -----------------------------
    # Coinbase WebSocket
    # -----------------------------
    async def _run_coinbase_ws(self):
        """Coinbase WebSocket loop with REST fallback."""
        reconnect_attempts = 0
        max_attempts = 3

        while self._running and reconnect_attempts < max_attempts:
            try:
                async with websockets.connect(self.config.COINBASE_WS_URL) as ws:
                    logger.info("Connected to Coinbase WebSocket.")
                    reconnect_attempts = 0

                    # Subscribe to BTC-USD ticker.
                    subscribe_msg = {
                        "type": "subscribe",
                        "product_ids": [self.config.COINBASE_SYMBOL],
                        "channels": ["ticker"],
                    }
                    await ws.send(json.dumps(subscribe_msg))

                    while self._running:
                        try:
                            msg = await asyncio.wait_for(ws.recv(), timeout=10.0)
                            data = json.loads(msg)
                            if data.get("type") == "ticker":
                                price = float(data.get("price", 0))
                                timestamp_ms = int(time.time() * 1000)
                                if price > 0:
                                    self._add_price(timestamp_ms, price)
                        except asyncio.TimeoutError:
                            logger.warning("Coinbase WebSocket timeout. Reconnecting...")
                            break
                        except Exception as e:
                            logger.error("Coinbase WebSocket error: %s", e)
                            break
            except Exception as e:
                reconnect_attempts += 1
                logger.error(
                    "Coinbase WebSocket error (attempt %d/%d): %s",
                    reconnect_attempts,
                    max_attempts,
                    e,
                )
                if reconnect_attempts < max_attempts:
                    await asyncio.sleep(5)
                else:
                    logger.warning("Coinbase WebSocket failed. Switching to REST polling.")
                    self._tasks.append(asyncio.create_task(self._poll_rest()))
                    break

    # -----------------------------
    # Binance WebSocket
    # -----------------------------
    async def _run_binance_ws(self):
        """Binance WebSocket loop with REST fallback."""
        reconnect_attempts = 0
        max_attempts = 3

        while self._running and reconnect_attempts < max_attempts:
            try:
                async with websockets.connect(self.config.BINANCE_WS_URL) as ws:
                    logger.info("Connected to Binance WebSocket.")
                    reconnect_attempts = 0
                    while self._running:
                        try:
                            msg = await asyncio.wait_for(ws.recv(), timeout=10.0)
                            data = json.loads(msg)
                            price = float(data.get("p", 0))
                            timestamp_ms = int(data.get("T", time.time() * 1000))
                            if price > 0:
                                self._add_price(timestamp_ms, price)
                        except asyncio.TimeoutError:
                            logger.warning("Binance WebSocket timeout. Reconnecting...")
                            break
                        except Exception as e:
                            logger.error("Binance WebSocket error: %s", e)
                            break
            except Exception as e:
                reconnect_attempts += 1
                logger.error(
                    "Binance WebSocket error (attempt %d/%d): %s",
                    reconnect_attempts,
                    max_attempts,
                    e,
                )
                if reconnect_attempts < max_attempts:
                    await asyncio.sleep(5)
                else:
                    logger.warning("Binance WebSocket failed. Switching to REST polling.")
                    self._tasks.append(asyncio.create_task(self._poll_rest()))
                    break

    # -----------------------------
    # REST Polling Fallback
    # -----------------------------
    async def _poll_rest(self):
        """Poll multiple REST endpoints as fallback."""
        logger.info("Starting REST polling fallback.")

        # Order of REST endpoints to try.
        endpoints = [
            ("coinbase", self.config.COINBASE_REST_URL, self._parse_coinbase_rest),
            ("binance", self.config.BINANCE_REST_URL, self._parse_binance_rest),
            ("kraken", self.config.KRAKEN_REST_URL, self._parse_kraken_rest),
        ]

        # Move preferred source to the front.
        preferred = self.config.SPOT_FEED_SOURCE
        endpoints = sorted(
            endpoints,
            key=lambda x: 0 if x[0] == preferred else 1,
        )

        while self._running:
            for name, url, parser in endpoints:
                try:
                    async with aiohttp.ClientSession() as session:
                        async with session.get(url, timeout=5.0) as resp:
                            resp.raise_for_status()
                            data = await resp.json()
                            price = parser(data)
                            if price and price > 0:
                                self._add_price(int(time.time() * 1000), price)
                                logger.debug("Got price from %s REST: $%.2f", name, price)
                                break
                except Exception as e:
                    logger.debug("REST fallback %s failed: %s", name, e)
                    continue
            else:
                logger.warning("All REST fallbacks failed.")

            await asyncio.sleep(2.0)

    @staticmethod
    def _parse_coinbase_rest(data: dict) -> Optional[float]:
        try:
            return float(data.get("price", 0))
        except Exception:
            return None

    @staticmethod
    def _parse_binance_rest(data: dict) -> Optional[float]:
        try:
            return float(data.get("price", 0))
        except Exception:
            return None

    @staticmethod
    def _parse_kraken_rest(data: dict) -> Optional[float]:
        try:
            result = data.get("result", {})
            pair_data = result.get("XBTUSD") or result.get("XXBTZUSD")
            if pair_data:
                # Kraken returns [a, b, c, v, p, ...] where c is last trade price.
                return float(pair_data["c"][0])
        except Exception:
            return None
        return None

    # -----------------------------
    # Public API
    # -----------------------------
    def _add_price(self, timestamp_ms: int, price: float):
        """Add a price point and clean old ones."""
        self.prices.append((timestamp_ms, price))
        self.latest_price = price
        self.latest_time = timestamp_ms / 1000.0

        # Remove prices older than history window.
        cutoff = timestamp_ms - (self.history_seconds * 1000)
        while self.prices and self.prices[0][0] < cutoff:
            self.prices.popleft()

    def get_price_change(self, lookback_seconds: float) -> Optional[float]:
        """
        Return the relative price change over the lookback window.
        E.g. 0.005 means price went up 0.5%.
        Returns None if not enough data.
        """
        if not self.latest_price or not self.prices:
            return None

        cutoff_ms = time.time() * 1000 - (lookback_seconds * 1000)

        # Find the oldest price in the window.
        old_price = None
        for ts, price in self.prices:
            if ts >= cutoff_ms:
                old_price = price
                break

        if old_price is None or old_price <= 0:
            return None

        return (self.latest_price - old_price) / old_price

    def get_latest(self) -> Optional[float]:
        """Return the latest BTC price."""
        return self.latest_price

    def has_price(self) -> bool:
        """Return True if we have at least one price."""
        return self.latest_price is not None
