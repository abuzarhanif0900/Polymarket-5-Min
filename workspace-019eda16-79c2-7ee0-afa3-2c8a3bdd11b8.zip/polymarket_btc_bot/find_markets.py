"""
Helper script to find active BTC/crypto markets and events on Polymarket.

Run with:
    python find_markets.py

It will print the current 5-minute BTC market and some daily up/down events.
"""

import asyncio
from datetime import datetime, timezone

import aiohttp

from config import BotConfig
from polymarket_client import PolymarketClient


async def main():
    config = BotConfig()

    print("=" * 80)
    print("Current 5-minute BTC market")
    print("=" * 80)

    # Try to find the current 5-minute round automatically.
    client = PolymarketClient(config)
    market = await client.find_current_5min_btc_market()
    if market:
        start = datetime.fromtimestamp(market["round_start_ts"], timezone.utc).strftime("%H:%M")
        end = datetime.fromtimestamp(market["round_end_ts"], timezone.utc).strftime("%H:%M")
        print(f"Market: {market['question']}")
        print(f"Round:  {start} UTC - {end} UTC")
        print(f"Event slug: {market['event_slug']}")
        print(f"Condition ID: {market['condition_id']}")
        print(f"End date: {market['end_date']}")
    else:
        print("Could not find current 5-minute BTC market.")

    print("\n" + "=" * 80)
    print("Other daily BTC/crypto up/down markets")
    print("=" * 80)

    async with aiohttp.ClientSession() as session:
        candidate_slugs = [
            "bitcoin-up-or-down-on-june-18-2026",
            "bitcoin-up-or-down-on-june-19-2026",
            "ethereum-up-or-down-on-june-18-2026",
            "xrp-up-or-down-on-june-18-2026",
            "solana-up-or-down-on-june-18-2026",
        ]

        for slug in candidate_slugs:
            url = f"{config.POLY_GAMMA_API}/events?slug={slug}"
            try:
                async with session.get(url) as resp:
                    if resp.status != 200:
                        continue
                    events = await resp.json()
                    if not isinstance(events, list) or not events:
                        continue
                    event = events[0]
                    markets = event.get("markets", [])
                    if not markets:
                        continue

                    market = markets[0]
                    print(f"\nEvent: {event.get('title')}")
                    print(f"  Event slug: {event.get('slug')}")
                    print(f"  Condition ID: {market.get('conditionId')}")
                    print(f"  End date: {market.get('endDate')}")
                    print(f"  Volume: {market.get('volume')}")
            except Exception as e:
                print(f"Error checking {slug}: {e}")

    print("\n" + "=" * 80)
    print("How to use")
    print("=" * 80)
    print("For 5-minute auto-rotation, set in config.py:")
    print("    AUTO_ROTATE_5MIN = True")
    print("    FIVE_MIN_SLUG_TEMPLATE = 'btc-updown-5m-{timestamp}'")
    print("\nFor a fixed market, set one of these in config.py:")
    print("    TARGET_EVENT_SLUG = 'btc-updown-5m-1781775300'")
    print("    # OR")
    print("    TARGET_MARKET_CONDITION_ID = '0x...'")


if __name__ == "__main__":
    asyncio.run(main())
