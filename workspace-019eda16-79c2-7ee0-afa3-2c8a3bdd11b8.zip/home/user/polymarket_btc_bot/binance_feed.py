"""
Binance BTC spot price feed.

This module provides a real-time BTC price using Binance WebSocket.
If the WebSocket fails, it falls back to Binance REST API.
"""

import asyncio
import json
import logging
import time
from collections import deque
from typing import Deque, Optional

import aiohttp
import websockets

logger = logging.getLogger(__name__)


class BinanceFeed:
    """Real-time BTC spot price feed from Binance."""

    def __init__(self, config):
        self.symbol = config.BINANCE_SYMBOL
        self.ws_url = config.BINANCE_WS_URL
        self.rest_url = config.BINANCE_REST_URL
        self.history_seconds = config.SPOT_HISTORY_SECONDS

        # Price history: list of (timestamp_ms, price).
        self.prices: Deque[tuple] = deque()

        # Latest price.
        self.latest_price: Optional[float] = None
        self.latest_time: Optional[float] = None

        # Control flag.
        self._running = False
        self._task: Optional[asyncio.Task] = None

    async def start(self):
        """Start the WebSocket feed."""
        self._running = True
        self._task = asyncio.create_task(self._run_ws())
        logger.info("Binance feed started: %s", self.ws_url)

    async def stop(self):
        """Stop the WebSocket feed."""
        self._running = False
        if self._task:
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass
        logger.info("Binance feed stopped.")

    async def _run_ws(self):
        """WebSocket loop with reconnect."""
        while self._running:
            try:
                async with websockets.connect(self.ws_url) as ws:
                    logger.info("Connected to Binance WebSocket.")
                    while self._running:
                        try:
                            msg = await asyncio.wait_for(ws.recv(), timeout=10.0)
                            data = json.loads(msg)
                            price = float(data.get("p", 0))
                            timestamp_ms = int(data.get("T", time.time() * 1000))
                            if price > 0:
                                self._add_price(timestamp_ms, price)
                        except asyncio.TimeoutError:
                            logger.warning("Binance WebSocket timeout. Reconnecting...")
                            break
                        except Exception as e:
                            logger.error("Binance WebSocket error: %s", e)
                            break
            except Exception as e:
                logger.error("Binance connection error: %s. Retrying in 5s...", e)
                await asyncio.sleep(5)

    def _add_price(self, timestamp_ms: int, price: float):
        """Add a price point and clean old ones."""
        self.prices.append((timestamp_ms, price))
        self.latest_price = price
        self.latest_time = timestamp_ms / 1000.0

        # Remove prices older than history window.
        cutoff = timestamp_ms - (self.history_seconds * 1000)
        while self.prices and self.prices[0][0] < cutoff:
            self.prices.popleft()

    def get_price_change(self, lookback_seconds: float) -> Optional[float]:
        """
        Return the relative price change over the lookback window.
        E.g. 0.005 means price went up 0.5%.
        Returns None if not enough data.
        """
        if not self.latest_price or not self.prices:
            return None

        cutoff_ms = time.time() * 1000 - (lookback_seconds * 1000)

        # Find the oldest price in the window.
        old_price = None
        for ts, price in self.prices:
            if ts >= cutoff_ms:
                old_price = price
                break

        if old_price is None or old_price <= 0:
            return None

        return (self.latest_price - old_price) / old_price

    async def _rest_fallback(self) -> Optional[float]:
        """Fallback to Binance REST if WebSocket is not available."""
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(self.rest_url) as resp:
                    data = await resp.json()
                    price = float(data.get("price", 0))
                    if price > 0:
                        self._add_price(int(time.time() * 1000), price)
                        return price
        except Exception as e:
            logger.error("Binance REST fallback failed: %s", e)
        return None

    def get_latest(self) -> Optional[float]:
        """Return the latest BTC price."""
        return self.latest_price
