"""
Paper trader (simulator) for Polymarket 5-minute BTC markets.

In dry-run mode, this module simulates trades and tracks P&L.
It assumes:
- You buy at the best ask price (taker) or your maker price gets filled.
- For simplicity, paper trades assume immediate fill at mid price minus a small slippage.
- The market resolves to 0 or 1 at expiry based on the actual BTC price.

Note: This is a simplified simulation. Real fills depend on orderbook depth.
"""

import csv
import logging
import os
import time
from dataclasses import dataclass, field
from typing import List, Optional

logger = logging.getLogger(__name__)


@dataclass
class PaperPosition:
    """A simulated open position."""

    side: str  # "UP" or "DOWN"
    entry_price: float
    size_usd: float
    entry_time: float
    market_question: str
    exit_price: Optional[float] = None
    exit_time: Optional[float] = None
    pnl: Optional[float] = None
    status: str = "open"  # "open" or "closed"


class PaperTrader:
    """Simulates trades and tracks P&L in paper trading mode."""

    def __init__(self, config):
        self.config = config
        self.positions: List[PaperPosition] = []
        self.closed_positions: List[PaperPosition] = []
        self.daily_pnl: float = 0.0
        self.daily_wins: int = 0
        self.daily_losses: int = 0
        self.trades_today: int = 0
        self.last_trade_time: float = 0.0

        # CSV setup.
        self.csv_file = config.TRADES_CSV
        self._init_csv()

    def _init_csv(self):
        """Create CSV file with headers if it does not exist."""
        if not os.path.exists(self.csv_file):
            with open(self.csv_file, "w", newline="") as f:
                writer = csv.writer(f)
                writer.writerow(
                    [
                        "timestamp",
                        "side",
                        "entry_price",
                        "size_usd",
                        "exit_price",
                        "pnl",
                        "status",
                        "market",
                    ]
                )

    def can_trade(self) -> bool:
        """Check if we are allowed to place another trade right now."""
        # Daily loss limit.
        max_daily_loss = self.config.CAPITAL_USD * self.config.DAILY_MAX_LOSS_PCT
        if self.daily_pnl <= -max_daily_loss:
            logger.warning(
                "Daily loss limit reached: $%.2f (limit: $%.2f). Stopping.",
                -self.daily_pnl,
                max_daily_loss,
            )
            return False

        # Daily profit limit (optional safety).
        max_daily_profit = self.config.CAPITAL_USD * self.config.DAILY_MAX_PROFIT_PCT
        if self.daily_pnl >= max_daily_profit:
            logger.warning(
                "Daily profit target reached: $%.2f. Stopping for safety.",
                self.daily_pnl,
            )
            return False

        # Trade cooldown.
        if (time.time() - self.last_trade_time) < self.config.TRADE_COOLDOWN_SECONDS:
            return False

        return True

    def open_position(
        self, side: str, entry_price: float, size_usd: float, market_question: str
    ) -> Optional[PaperPosition]:
        """Open a simulated position."""
        if not self.can_trade():
            return None

        if size_usd <= 0:
            logger.warning("Trade size must be positive.")
            return None

        position = PaperPosition(
            side=side,
            entry_price=entry_price,
            size_usd=size_usd,
            entry_time=time.time(),
            market_question=market_question,
        )
        self.positions.append(position)
        self.last_trade_time = time.time()
        self.trades_today += 1

        logger.info(
            "PAPER TRADE: BUY %s | Size: $%.2f | Entry: %.4f | Market: %s",
            side,
            size_usd,
            entry_price,
            market_question,
        )
        return position

    def close_all_positions(self, final_up_price: Optional[float]):
        """
        Close all open positions at market resolution.
        For 5-minute BTC markets, the token resolves to 0 or 1.
        """
        if final_up_price is None:
            logger.warning("Cannot close positions: no final price.")
            return

        for position in self.positions:
            if position.status != "open":
                continue

            # Resolve value: UP token resolves to final_up_price, DOWN to 1 - final_up_price.
            if position.side == "UP":
                exit_price = final_up_price
            else:
                exit_price = 1.0 - final_up_price

            position.exit_price = exit_price
            position.exit_time = time.time()
            position.status = "closed"

            # PnL = (exit - entry) * shares.
            # shares = size_usd / entry_price (approximate).
            shares = position.size_usd / position.entry_price
            position.pnl = (exit_price - position.entry_price) * shares
            self.daily_pnl += position.pnl

            if position.pnl > 0:
                self.daily_wins += 1
            else:
                self.daily_losses += 1

            self._log_position(position)
            self.closed_positions.append(position)

            logger.info(
                "PAPER CLOSE: %s | Exit: %.4f | PnL: $%.2f",
                position.side,
                exit_price,
                position.pnl,
            )

        # Clear open positions list.
        self.positions = []

    def _log_position(self, position: PaperPosition):
        """Append a closed position to the CSV file."""
        with open(self.csv_file, "a", newline="") as f:
            writer = csv.writer(f)
            writer.writerow(
                [
                    time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(position.entry_time)),
                    position.side,
                    f"{position.entry_price:.4f}",
                    f"{position.size_usd:.2f}",
                    f"{position.exit_price:.4f}" if position.exit_price else "",
                    f"{position.pnl:.2f}" if position.pnl is not None else "",
                    position.status,
                    position.market_question,
                ]
            )

    def get_stats(self) -> dict:
        """Return current trading statistics."""
        total_trades = self.daily_wins + self.daily_losses
        win_rate = (self.daily_wins / total_trades * 100) if total_trades > 0 else 0.0
        return {
            "daily_pnl": self.daily_pnl,
            "daily_wins": self.daily_wins,
            "daily_losses": self.daily_losses,
            "win_rate": win_rate,
            "open_positions": len(self.positions),
            "closed_positions": len(self.closed_positions),
        }
