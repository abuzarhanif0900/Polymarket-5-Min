"""
Polymarket client for reading market data.

In paper trading mode, we only need public API access.
For live trading, you would use py-clob-client with API credentials.
"""

import asyncio
import logging
import time
from typing import Any, Dict, List, Optional

import aiohttp

logger = logging.getLogger(__name__)


class PolymarketClient:
    """Lightweight Polymarket client for public market data."""

    def __init__(self, config):
        self.config = config
        self.clob_host = config.POLY_CLOB_HOST
        self.gamma_api = config.POLY_GAMMA_API

        # Cache for active 5-minute BTC market.
        self._active_market: Optional[Dict[str, Any]] = None
        self._market_cache_time: float = 0
        self._market_cache_ttl: float = 60.0  # Refresh every 60 seconds.

        # Cache for orderbook.
        self._orderbook: Optional[Dict[str, Any]] = None
        self._orderbook_time: float = 0

    async def _get(self, url: str) -> Any:
        """Make a GET request and return JSON."""
        async with aiohttp.ClientSession() as session:
            async with session.get(url) as resp:
                resp.raise_for_status()
                return await resp.json()

    async def find_active_5min_btc_market(self) -> Optional[Dict[str, Any]]:
        """
        Find the currently active 5-minute BTC market on Polymarket.
        Returns a dict with condition_id, token_ids, question, etc.
        """
        now = time.time()
        if (
            self._active_market
            and (now - self._market_cache_time) < self._market_cache_ttl
        ):
            return self._active_market

        try:
            # Query Gamma API for active markets.
            url = (
                f"{self.gamma_api}/markets?"
                f"active=true&"
                f"closed=false&"
                f"archived=false&"
                f"limit=100"
            )
            data = await self._get(url)
            markets = data.get("markets", [])

            for market in markets:
                question = market.get("question", "").lower()
                slug = market.get("slug", "").lower()
                end_date = market.get("endDate")

                # Look for 5-minute BTC markets.
                is_btc = "btc" in question or "bitcoin" in question or "btc" in slug
                is_5min = "5-minute" in question or "5 minute" in question or "5m" in slug

                if is_btc and is_5min:
                    # Extract token IDs.
                    tokens = market.get("tokens", [])
                    up_token = None
                    down_token = None
                    for token in tokens:
                        outcome = token.get("outcome", "").lower()
                        if outcome in ["up", "yes"]:
                            up_token = token.get("token_id")
                        elif outcome in ["down", "no"]:
                            down_token = token.get("token_id")

                    if up_token and down_token:
                        self._active_market = {
                            "condition_id": market.get("conditionId"),
                            "question": market.get("question"),
                            "slug": market.get("slug"),
                            "end_date": end_date,
                            "up_token_id": up_token,
                            "down_token_id": down_token,
                        }
                        self._market_cache_time = now
                        logger.info(
                            "Found active market: %s", self._active_market["question"]
                        )
                        return self._active_market

            logger.warning("No active 5-minute BTC market found.")
            return None

        except Exception as e:
            logger.error("Failed to find active market: %s", e)
            return None

    async def get_orderbook(self, token_id: str) -> Optional[Dict[str, Any]]:
        """
        Get the orderbook for a token ID.
        Returns dict with 'bids' and 'asks' lists.
        """
        try:
            url = f"{self.clob_host}/book/{token_id}"
            data = await self._get(url)
            self._orderbook = data
            self._orderbook_time = time.time()
            return data
        except Exception as e:
            logger.error("Failed to get orderbook for %s: %s", token_id[:12], e)
            return None

    def get_orderbook_age(self) -> float:
        """Return age of the cached orderbook in seconds."""
        if self._orderbook is None:
            return float("inf")
        return time.time() - self._orderbook_time

    @staticmethod
    def get_mid_price(orderbook: Dict[str, Any]) -> Optional[float]:
        """Calculate mid price from best bid and best ask."""
        bids = orderbook.get("bids", [])
        asks = orderbook.get("asks", [])

        if not bids or not asks:
            return None

        best_bid = float(bids[0]["price"])
        best_ask = float(asks[0]["price"])
        return (best_bid + best_ask) / 2.0

    @staticmethod
    def get_spread(orderbook: Dict[str, Any]) -> Optional[float]:
        """Return bid-ask spread."""
        bids = orderbook.get("bids", [])
        asks = orderbook.get("asks", [])

        if not bids or not asks:
            return None

        best_bid = float(bids[0]["price"])
        best_ask = float(asks[0]["price"])
        return best_ask - best_bid
