"""
Main entry point for the Polymarket 5-minute BTC bot.

This bot:
1. Connects to Binance for real-time BTC spot price.
2. Finds the active 5-minute BTC market on Polymarket.
3. Monitors the orderbook for UP and DOWN tokens.
4. Generates a signal when BTC spot moves but the Polymarket token is lagging.
5. Simulates trades in paper trading mode (or real trades in live mode).
6. Closes positions at market expiry and reports P&L.

Run with:
    python main.py

Stop with Ctrl+C.
"""

import asyncio
import logging
import signal
import sys
import time
from datetime import datetime, timezone

from binance_feed import BinanceFeed
from config import BotConfig
from paper_trader import PaperTrader
from polymarket_client import PolymarketClient
from signal_engine import SignalEngine

# -------------------------------
# Setup Logging
# -------------------------------
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
    handlers=[
        logging.FileHandler("bot.log"),
        logging.StreamHandler(sys.stdout),
    ],
)
logger = logging.getLogger(__name__)


class TradingBot:
    """Main trading bot."""

    def __init__(self, config: BotConfig):
        self.config = config
        self.binance = BinanceFeed(config)
        self.polymarket = PolymarketClient(config)
        self.signal_engine = SignalEngine(config)
        self.trader = PaperTrader(config)

        self._running = False
        self._shutdown_event = asyncio.Event()

    async def run(self):
        """Main loop."""
        self._running = True

        # Start Binance feed.
        await self.binance.start()

        # Wait a moment for prices to arrive.
        logger.info("Waiting for Binance price feed...")
        for _ in range(10):
            if self.binance.get_latest() is not None:
                break
            await asyncio.sleep(0.5)

        if self.binance.get_latest() is None:
            logger.error("Could not get Binance price. Exiting.")
            await self.binance.stop()
            return

        logger.info("Bot started. DRY_RUN=%s", self.config.DRY_RUN)
        logger.info("Capital: $%.2f | Max trade: $%.2f", self.config.CAPITAL_USD, self.config.MAX_TRADE_SIZE_USD)

        # Find active market once.
        active_market = await self.polymarket.find_active_5min_btc_market()
        if not active_market:
            logger.error("No active 5-minute BTC market found. Exiting.")
            await self.binance.stop()
            return

        # Main loop.
        try:
            while self._running:
                # Check if we should exit.
                if self._shutdown_event.is_set():
                    break

                await self._tick(active_market)

                # Sleep before next check.
                await asyncio.sleep(2.0)

        except asyncio.CancelledError:
            logger.info("Main loop cancelled.")
        finally:
            logger.info("Shutting down...")
            await self.binance.stop()
            self._print_final_stats()

    async def _tick(self, active_market: dict):
        """One iteration of the trading loop."""
        # 1. Get spot price change.
        spot_change = self.binance.get_price_change(self.config.SPOT_LOOKBACK_SECONDS)
        latest_spot = self.binance.get_latest()

        # 2. Get orderbooks.
        up_book = await self.polymarket.get_orderbook(active_market["up_token_id"])
        down_book = await self.polymarket.get_orderbook(active_market["down_token_id"])

        # 3. Generate signal.
        signal = self.signal_engine.generate_signal(spot_change, up_book, down_book)

        # 4. Log status.
        logger.info(
            "Spot: $%.2f (change: %.4f) | UP: %.4f | DOWN: %.4f | Signal: %s | Reason: %s",
            latest_spot or 0.0,
            spot_change or 0.0,
            signal.up_mid or 0.0,
            signal.down_mid or 0.0,
            signal.side or "NONE",
            signal.reason,
        )

        # 5. Execute if signal exists and no open positions.
        if signal.side and not self.trader.positions:
            if self.trader.can_trade():
                entry_price = signal.up_mid if signal.side == "UP" else signal.down_mid
                self.trader.open_position(
                    side=signal.side,
                    entry_price=entry_price,
                    size_usd=self.config.MAX_TRADE_SIZE_USD,
                    market_question=active_market["question"],
                )
            else:
                logger.info("Signal generated but trading not allowed (risk/cooldown).")

        # 6. Check if market is about to expire and close positions.
        # For 5-minute markets, we close roughly 30 seconds before expiry.
        end_date = active_market.get("end_date")
        if end_date:
            try:
                # Parse ISO date.
                expiry = datetime.fromisoformat(end_date.replace("Z", "+00:00"))
                now_utc = datetime.now(timezone.utc)
                seconds_to_expiry = (expiry - now_utc).total_seconds()

                if seconds_to_expiry < 30 and self.trader.positions:
                    logger.info(
                        "Market expires in %.1f seconds. Closing paper positions.",
                        seconds_to_expiry,
                    )
                    # In a real bot, you would fetch the final oracle price.
                    # For paper trading, we use the current spot price to estimate resolution.
                    # This is a simplification.
                    final_up_price = self._estimate_up_resolution(latest_spot, up_book, down_book)
                    self.trader.close_all_positions(final_up_price)

            except Exception as e:
                logger.warning("Could not parse expiry date: %s", e)

        # 7. Print stats periodically.
        if int(time.time()) % 60 == 0:
            self._print_stats()

    def _estimate_up_resolution(
        self, latest_spot: float, up_book: Optional[dict], down_book: Optional[dict]
    ) -> float:
        """
        Estimate the final UP token resolution price.
        In reality, this is determined by the Chainlink oracle at expiry.
        For paper trading, we use the current orderbook mid as a proxy.
        """
        if up_book:
            bids = up_book.get("bids", [])
            asks = up_book.get("asks", [])
            if bids and asks:
                return (float(bids[0]["price"]) + float(asks[0]["price"])) / 2.0
        return 0.5

    def _print_stats(self):
        """Print current trading stats."""
        stats = self.trader.get_stats()
        logger.info(
            "STATS | PnL: $%.2f | Wins: %d | Losses: %d | Win Rate: %.1f%% | Open: %d",
            stats["daily_pnl"],
            stats["daily_wins"],
            stats["daily_losses"],
            stats["win_rate"],
            stats["open_positions"],
        )

    def _print_final_stats(self):
        """Print final stats on shutdown."""
        stats = self.trader.get_stats()
        logger.info("=" * 60)
        logger.info("FINAL STATS")
        logger.info("=" * 60)
        logger.info("Daily PnL:        $%.2f", stats["daily_pnl"])
        logger.info("Wins:             %d", stats["daily_wins"])
        logger.info("Losses:           %d", stats["daily_losses"])
        logger.info("Win Rate:         %.1f%%", stats["win_rate"])
        logger.info("Total Trades:     %d", stats["daily_wins"] + stats["daily_losses"])
        logger.info("=" * 60)

    def shutdown(self):
        """Signal the bot to shut down."""
        logger.info("Shutdown signal received.")
        self._running = False
        self._shutdown_event.set()


async def main():
    config = BotConfig()
    bot = TradingBot(config)

    # Handle Ctrl+C.
    loop = asyncio.get_event_loop()
    for sig in (signal.SIGINT, signal.SIGTERM):
        loop.add_signal_handler(sig, bot.shutdown)

    await bot.run()


if __name__ == "__main__":
    asyncio.run(main())
