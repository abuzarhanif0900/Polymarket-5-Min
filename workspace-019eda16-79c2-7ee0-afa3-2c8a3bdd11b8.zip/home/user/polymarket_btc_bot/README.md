# Polymarket 5-Minute BTC Trading Bot

A beginner-friendly Python bot for trading Polymarket's 5-minute BTC up/down markets. **It starts in paper trading mode by default** so you can test safely.

## What It Does

- Connects to **Binance** for real-time BTC spot price.
- Finds the currently active **5-minute BTC market** on Polymarket.
- Watches the **UP** and **DOWN** token orderbooks.
- Generates a **signal** when BTC spot moves but the Polymarket token is lagging.
- Simulates trades in **paper trading mode** and tracks P&L in a CSV file.
- Has risk management: daily loss limit, trade cooldown, max trade size.

## ⚠️ Important

This bot is for **learning and testing**. It is **not guaranteed to make money**. 5-minute markets are extremely competitive, and fees/slippage can erase small edges.

## Setup

### 1. Install Python

You need Python 3.10 or higher.

### 2. Install Dependencies

```bash
cd polymarket_btc_bot
pip install -r requirements.txt
```

### 3. Run in Paper Trading Mode

```bash
python main.py
```

This will:
- Start the Binance price feed.
- Find the active 5-minute BTC market.
- Log signals and simulate trades.
- Save simulated trades to `trades.csv`.
- Log everything to `bot.log` and the console.

### 4. Stop the Bot

Press `Ctrl+C`.

## Configuration

Open `config.py` and adjust:

| Setting | What It Does | Default |
|---------|--------------|---------|
| `DRY_RUN` | True = paper trading, False = live trading | `True` |
| `CAPITAL_USD` | Total capital you are risking | `$100` |
| `MAX_TRADE_SIZE_USD` | Max dollars per trade | `$5` |
| `DAILY_MAX_LOSS_PCT` | Stop trading after losing this % of capital | `20%` |
| `SPOT_MOVE_THRESHOLD` | Minimum BTC spot move to trigger a signal | `0.1%` |
| `SPOT_LOOKBACK_SECONDS` | How far back to measure BTC spot move | `15s` |
| `USE_MAKER_ONLY` | Use maker orders to avoid taker fees | `True` |

## How the Signal Works

The bot uses a **spot lead** strategy:

1. If BTC spot price went up in the last 15 seconds, the UP token should also go up.
2. If the UP token has **not** moved yet (mid price < 0.55), the bot simulates buying UP.
3. If BTC spot price went down, the bot looks to buy DOWN if it is lagging.

This only works if Polymarket is slow to react to spot moves. On fast markets, the signal will be too late.

## Live Trading

To switch to live trading:

1. Copy `.env.example` to `.env`:
   ```bash
   cp .env.example .env
   ```
2. Fill in your Polymarket API credentials and private key.
3. Change `DRY_RUN` to `false` in `config.py` or `.env`.
4. **Only use a small amount of capital that you can afford to lose.**

## Files

- `main.py` — Entry point.
- `config.py` — All settings.
- `binance_feed.py` — BTC spot price feed.
- `polymarket_client.py` — Polymarket market data.
- `signal_engine.py` — Signal generation logic.
- `paper_trader.py` — Paper trading simulator and P&L tracker.
- `trades.csv` — Simulated trade history.
- `bot.log` — Detailed logs.

## Next Steps

1. **Run it in paper mode for at least a few hours.**
2. Check the win rate and P&L in the logs and `trades.csv`.
3. If results look good, consider live trading with **$5–10** first.
4. If results are bad, tweak the signal settings or try a different strategy.

## Risks

- **No guaranteed profit.** This is a competitive market.
- **Slippage and fees** can turn a winning signal into a losing trade.
- **Latency** matters. Running locally may be slower than a cloud server.
- **Past performance** does not predict future results.

## Need Help?

If you want to improve the bot, here are some ideas:
- Add more signal sources (funding rates, orderbook imbalance, social sentiment).
- Improve execution to use maker orders properly.
- Add a more sophisticated exit strategy instead of holding to expiry.
- Run on a VPS closer to Polymarket's servers for lower latency.
