"""
Configuration for the Polymarket 5-minute BTC trading bot.

All tunable settings are here. For live trading, you will set your
Polymarket API credentials in the .env file.
"""

from dataclasses import dataclass
from typing import Optional


@dataclass
class BotConfig:
    """Bot configuration."""

    # -------------------------------
    # Trading Mode
    # -------------------------------
    # True = paper trading (no real orders). False = live trading.
    DRY_RUN: bool = True

    # -------------------------------
    # Capital & Risk
    # -------------------------------
    # Total capital you are willing to risk.
    CAPITAL_USD: float = 100.0

    # Maximum USD per trade.
    MAX_TRADE_SIZE_USD: float = 5.0

    # Stop trading if daily loss reaches this percentage of capital.
    DAILY_MAX_LOSS_PCT: float = 0.20  # 20% of $100 = $20

    # Stop trading if daily profit reaches this percentage (optional safety).
    DAILY_MAX_PROFIT_PCT: float = 0.50  # 50% of $100 = $50

    # Max number of trades per 5-minute round.
    MAX_TRADES_PER_ROUND: int = 1

    # Cooldown between trades in seconds.
    TRADE_COOLDOWN_SECONDS: float = 30.0

    # -------------------------------
    # Signal Settings
    # -------------------------------
    # How many seconds of spot price history to keep.
    SPOT_HISTORY_SECONDS: int = 120

    # Minimum spot price move (in decimal, e.g. 0.001 = 0.1%) to trigger a signal.
    SPOT_MOVE_THRESHOLD: float = 0.001

    # Lookback window in seconds for measuring the spot move.
    SPOT_LOOKBACK_SECONDS: float = 15.0

    # Maximum age of the Polymarket orderbook in seconds before we ignore it.
    ORDERBOOK_MAX_AGE_SECONDS: float = 5.0

    # -------------------------------
    # Polymarket Settings
    # -------------------------------
    # Polymarket CLOB host.
    POLY_CLOB_HOST: str = "https://clob.polymarket.com"

    # Chain ID for Polygon mainnet.
    POLY_CHAIN_ID: int = 137

    # Gamma API for market discovery.
    POLY_GAMMA_API: str = "https://gamma-api.polymarket.com"

    # Market filter: look for markets with this in the title.
    MARKET_KEYWORDS: tuple = ("bitcoin", "btc", "5-minute")

    # -------------------------------
    # Binance Spot Feed
    # -------------------------------
    BINANCE_SYMBOL: str = "BTCUSDT"
    BINANCE_WS_URL: str = "wss://stream.binance.com:9443/ws/btcusdt@trade"

    # Optional: Binance REST fallback URL.
    BINANCE_REST_URL: str = "https://api.binance.com/api/v3/ticker/price?symbol=BTCUSDT"

    # -------------------------------
    # Execution
    # -------------------------------
    # Use maker orders only (post_only=True) to avoid taker fees.
    # Polymarket has 0% maker fee and ~0.2-0.4% taker fee.
    USE_MAKER_ONLY: bool = True

    # Price offset for maker orders (in cents on the $0-1 price scale).
    # E.g. 0.002 means place order 0.2% better than mid price.
    MAKER_PRICE_OFFSET: float = 0.002

    # -------------------------------
    # Logging
    # -------------------------------
    # CSV file to track simulated trades.
    TRADES_CSV: str = "trades.csv"

    # Log level: DEBUG, INFO, WARNING, ERROR.
    LOG_LEVEL: str = "INFO"

    # -------------------------------
    # Polymarket API Credentials (for live trading only)
    # -------------------------------
    # These are loaded from environment variables or .env file.
    POLY_PRIVATE_KEY: Optional[str] = None
    POLY_FUNDER_ADDRESS: Optional[str] = None
    POLY_API_KEY: Optional[str] = None
    POLY_API_SECRET: Optional[str] = None
    POLY_API_PASSPHRASE: Optional[str] = None
